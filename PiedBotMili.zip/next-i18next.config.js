module.exports = {
    i18n: {
      locales: ['en', 'fr', 'ar'],
      defaultLocale: 'en',
    },
    react: { useSuspense: false },
};